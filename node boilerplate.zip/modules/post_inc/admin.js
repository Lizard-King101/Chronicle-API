const db = require('../database');
const bcrypt = require('bcryptjs');
const formidable = require('formidable');
const fs = require('fs');
const path = require('path');
const notifications = require('../notifications');

function Process(options) {
    let POST = options.POST;
    let GET = options.GET;
    let urlArr = options.urlArr;
    let action = urlArr[1];
    let req = options.request;
    let cookies = options.cookies;

    let auth = cookies['x-auth'] || req.headers['x-auth'];
    if(Object.keys(POST).length = 0) POST = null;
    
    return new Promise((res, rej) => {


        switch(action) {
            /* SIGNIN ACTIONS */
            case 'signin':
                if(POST.email && POST.pass ){
                    db.query(`SELECT * FROM accounts WHERE email = '${POST.email.toLowerCase()}'`).then( async (result)=>{
                        if(result && !result.error){
                            let user = result[0];
                            if(POST.pass === user.password && user.is_admin){
                                if(!user.auth_token || user.auth_token == '' || user.auth_token == 'null') {
                                    let salt = await bcrypt.genSalt(10);
                                    let hash = await bcrypt.hash(user.username, salt);
                                    user.auth_token = hash;
                                    db.update({
                                        table: 'accounts',
                                        data: {auth_token: hash},
                                        where: `id = ${user.id}`
                                    }).then((data) => {
                                        console.log(data);

                                        req.session.user = user;
                                        res(user);
                                    })
                                } else {
                                    req.session.user = user;
                                    res(user);
                                }
                                
                            }else{
                                res(false);
                            }
                        } else {
                            res(false);
                        }
                    })
                }
                break;
            case 'check-signin':
                if(auth && POST.user){
                    let user = POST.user;
                    db.query(`SELECT * FROM accounts WHERE email = '${user.email}' AND auth_token = '${auth}'`).then((result)=>{
                        console.log(result);
                        if(result && !result.error){
                            res(result);
                        } else {
                            res(false);
                        }
                    });
                } else {
                    res(false);
                }
                break;
            
            case 'list-categories':
                db.query('SELECT * FROM categories').then((result) => {
                    console.log('CATEGORIES',result);
                    if(result && !result.error){
                        res(result);
                    } else {
                        res(false);
                    }
                });
                break;

            /* RAFFLE ACTIONS */
            case 'list-raffles':
                new Promise((next) => {
                    let order = ' ORDER BY r.created DESC';
                    if(POST.order_by && POST.order) {
                        order = ` ORDER BY r.${POST.order_by} ${POST.order}`
                    }
                    let q = `SELECT * FROM raffles r ${order}`;
                    next(q);
                }).then((q) => {
                    db.query(q).then((result) => {
                        if(result && !result.error){
                            res(result);
                        } else {
                            res(false);
                        }
                    });
                });
                break;
            case 'raffle-resources':
                if(POST.id) {
                    db.select({table: 'raffle_resources', where: [`raffle = '${POST.id}'`]}).then((result) => {
                        if(result && !result.error){
                            res(result);
                        } else {
                            res(false);
                        }
                    })
                }else {
                    res(false);
                }                
                break;
            case 'raffle':
                var form = new formidable.IncomingForm();
                form.parse(req, async (err, fields, files) => {
                    POST = JSON.parse(fields.post);
                    let extra_data = {
                        insert_data: null,
                        insert_query: null,
                    };
                    let raffleID = POST.id ? POST.id : (await db.getRow(`SELECT id FROM raffles ORDER BY id DESC limit 1`)).id + 1;
                    new Promise((res) => {
                        let length = Object.keys(files).length;
                        if(length > 0) {
                            Object.keys(files).forEach((id, i) => {
                                let file = files[id];
                                let name = id + '.' + file.type.split('/').pop();
                                let data = {
                                    id,
                                    raffle: raffleID,
                                    sort_order: i,
                                    url: '_media/'+name
                                }
                                let dest = path.join(global.paths.root, 'public/media', name);
                                POST.old_resources.push(id);
                                db.insert('raffle_resources', data).then((result)=>{
                                    let stream = fs.createWriteStream(dest);
                                    fs.createReadStream(file.path).pipe(stream);
                                    if(i >= length -1) res();
                                })
                            })
                        } else {
                            res();
                        }
                    }).then(async () => {
                        if(POST.id) {
                            let resources = await db.select({table: 'raffle_resources', where: [`raffle = '${POST.id}'`]});
                            let deleteResources = [];
                            for(let i = 0; i < resources.length; i ++) {
                                let row = resources[i];
                                if(POST.old_resources.indexOf(row.id) <= -1) {
                                    deleteResources.push(row.id);
                                }
                            }
                            if(deleteResources.length > 0) {
                                await db.query(`DELETE FROM raffle_resources WHERE id IN ${( '("' + deleteResources.join('","') + '")' )}`);
                            }
                            let data = await db.loadData('raffles', POST);
                            result = await db.update({table: 'raffles', data, where: `id = '${POST.id}'`});
                        } else {
                            POST.id = raffleID;
                            POST.created = new Date().toISOString();
                            delete POST.old_resources;
                            let data = extra_data.insert_data = await db.loadData('raffles', POST);
                            extra_data.insert_query = await db.insert('raffles', data);
                        }
                        res({ok: true, extra_data})
                    });
                });
                
                break;
            case 'delete-raffle':
                if(POST.id) {
                    db.select({table: 'raffle_resources', where: [`raffle = '${POST.id}'`]}).then((resources) => {

                    })
                }
                break;


            /* NOTIFICATION ACTIONS */
            case 'list-notifications':
                new Promise((next) => {
                    let order = ' ORDER BY n.send DESC';
                    if(POST.order_by && POST.order) {
                        order = ` ORDER BY n.${POST.order_by} ${POST.order}`
                    }
                    let q = `SELECT * FROM notifications n ${order}`;
                    next(q);
                }).then((q) => {
                    db.query(q).then((result) => {
                        if(result && !result.error){
                            res(result);
                        } else {
                            res(false);
                        }
                    });
                });
                break;
            case 'notification':
                console.log(POST);
                if(POST.id) {
                    let id = POST.id
                    delete POST.id;
                    db.update({table: 'notifications', data: POST, where: ` id = '${id}'`}).then((result) => {
                        res(result)
                    })
                } else {
                    db.insert('notifications', POST).then((result) => {
                        res(result)
                    })
                }
                break;
            case 'send-test-notification': 
                if(POST.notification_id) {
                    notifications.sendNotifications({notification: POST.notification_id, test: true}).then((result) => {
                        res(result);
                    })
                }
                break;
            case 'delete-notification':
                if(POST.id) {
                    db.query(`DELETE FROM notifications WHERE id = '${POST.id}'`).then((result) => {
                        res(result);
                    })
                }
                break;
            

            /* USER ACTIONS */
            case 'list':
                if(POST && POST.table && POST.order_by && POST.order) {
                    let table = ({users: 'accounts', raffles: 'raffles', not: 'notifications'})[POST.table];
                    let columns = ['*']
                    if(table == 'raffles') columns.push(' (SELECT COUNT(*) FROM tickets ti WHERE ti.raffle_id = t.id) as tickets_sold')
                    if(table) {
                        let page = POST.page && typeof POST.page == 'number' ? POST.page * 20 : 0;
                        new Promise((next) => {
                            let order = ` ORDER BY t.${POST.order_by} ${POST.order}`;
                            next(`SELECT ${columns.join(',')} FROM ${table} t ${order} LIMIT 20 OFFSET ${page}`);
                        }).then(async (q) => {
                            let total = (await db.query(`SELECT COUNT(*) as total FROM ${table}`))[0]['total'];
                            db.query(q).then((result) => {
                                if(result && !result.error){
                                    res({total, data: result});
                                } else {
                                    res(false);
                                }
                            });
                        });
                    } else {
                        res(false);
                    }
                } else {
                    res(false);
                }
                break;
            case 'user':
                console.log(POST);
                if(POST.id) {
                    let id = POST.id;
                    delete POST.id;
                    for(let key of Object.keys(POST)) {
                        let value = POST[key];
                        if(value == 'null') {
                            POST[key] = null;
                        }
                    }
                    db.update({table: 'accounts', data: POST, where: ` id = '${id}'`}).then((result) => {
                        res(result)
                    })
                } else {
                    db.insert('accounts', POST).then((result) => {
                        res(result)
                    })
                }
                break;

            /* END ACTIONS */
            default: 
                rej({message: `Action '${action}' not found in: admin.js`});
                break;
        }
        setTimeout(() => {
            rej({message: `No resolve for action ${action} in admin.js`});
        }, 5000);
    })
}

function createID() {
    return new Date().getTime().toString(36).substr(2, 9);
}

module.exports.process = Process;