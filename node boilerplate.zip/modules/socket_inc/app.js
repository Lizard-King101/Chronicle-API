const path = require('path');
const fs = require('fs');
const db = require('../database');
const Rand  = require('random-org');
const random = new Rand(global.random);
const bcrypt = require('bcryptjs');
const Timer = require('../timer');

var io = global.io;
var connected = global.socketio.connected;

var timers = {

}

function Process(socket) {
    socket.on('register', (user) => {
        if(user) {
            socket.user_id = user.id;
            socket.app = 'mobile';
            connected.users[user.id] = socket.id;
            io.sockets.in('admin').emit('metric-users', Object.keys(connected.users).length);
            socket.join('users');
        } else {
            socket.emit('register-request');
        }
    });

    socket.on('reserve-ticket', async (data) => {
        let ticket = data.ticket;
        let edit = data.edit;
        let cart_id;
        let itemExsists;
        let reserved_nums = [];
        let expired_nums = [];
        //5 * 6
        let expires = new Date().getTime() + 5 * 60 * 1000;

        let cart = await db.getRow(`SELECT * FROM carts WHERE user = '${socket.user_id}'`);
        let items = await db.query(`SELECT ci.item_id, ci.cart_id, GROUP_CONCAT(ci.ticket_num) as ticket_nums FROM cart_items ci JOIN carts c ON (c.id = ci.cart_id) WHERE c.user = '${socket.user_id}' GROUP BY ci.item_id`);
        
        // track items left
        let count_update = -ticket.count;
        let delete_item = false;
        
        // check if cart exsists else create and get id
        if(!cart) {
            cart = await db.insert('carts', {user: socket.user_id});
            cart_id = cart.insertId;
        } else {
            cart_id = cart.id;
        }

        // check if target items is currently added to 
        if(items.length > 0) {
            for(let item of items) {
                if(item.item_id == ticket.item_id) {
                    itemExsists = item;
                    break;
                }
            };
        }
        console.log(items);
        if(itemExsists) {
            let last_nums = itemExsists.ticket_nums.split(',');
            
            let insert_nums = reserved_nums = ticket.ticket_nums.filter(n => !last_nums.includes(n));
            let data = {
                item_id: ticket.item_id,
                cart_id: cart_id
            }
            if(insert_nums.length > 0) {
                for(let n = 0; n < insert_nums.length; n ++) {
                    data.ticket_num = insert_nums[n];
                    db.insert('cart_items', data);
                }
            }
            let delete_nums = last_nums.filter(n => !ticket.ticket_nums.includes(n));
            if(delete_nums.length > 0 && edit) {
                expired_nums = delete_nums;
                let q = `DELETE FROM cart_items WHERE item_id = '${ticket.item_id}' AND ticket_num in (${`'` + delete_nums.join(`','`) + `'`})`;
                console.log('DELETE CI', q)
                db.query(q);
                
            }
        } else {
            let data = {
                item_id: ticket.item_id,
                cart_id: cart_id
            }
            for(let i = 0; i < ticket.ticket_nums.length; i++) {
                let num = ticket.ticket_nums[i];
                data.ticket_num = num;
                let info = await db.insert('cart_items', data);
                if(info && !info.error) {
                    reserved_nums.push(num);
                }
            }
        }
        
        if(!timers[socket.user_id]) {
            timers[socket.user_id] = {};
        }
        
        console.log(reserved_nums, expired_nums);

        // if(timers[socket.user_id][cart_id]) {
        //     if(delete_item) {
        //         timers[socket.user_id][cart_id].cancel();
        //         delete timers[socket.user_id][cart_id];
        //     } else {
        //         timers[socket.user_id][cart_id].updateExpiration(expires);
        //     }
        // } else {
        //     let timer =  new Timer();
        //     timer.at(expires).subscribe(() => {onItemExpire(cart_id)});
        //     timers[socket.user_id][cart_id] = timer;
        // }

        io.sockets.in('users').emit('reservation-update', [{item_id: ticket.item_id, reserved_nums, expired_nums, user: socket.user_id}]);
        socket.emit('cart-update');
    })

    socket.on('cart-checkout', async () => {
        let items = await db.query(`SELECT ci.ticket_num, ci.item_id, c.user, c.id as cart_id FROM cart_items ci JOIN carts c ON (c.id = ci.cart_id) WHERE c.user = '${socket.user_id}'`);
        let cart_id;
        let updated_items = [];
        if(items && items.length > 0) {
            let tickets = [];
            random.generateDecimalFractions({
                n: items.length,
                decimalPlaces: 10
            }).then(async (randomData) => {
                for(let i = 0; i < items.length; i++) {
                    item = items[i];
                    if(!cart_id) cart_id = item.cart_id;
                    if(!updated_items.includes(item.item_id)) updated_items.push(item.item_id);
                    let randomValue = randomData.random.data[i];
                    let salt = await bcrypt.genSalt(10);
                    let hash = await bcrypt.hash(randomValue + '', salt);
                    let ticket = {
                        ticket_num: item.ticket_num,
                        user_id: item.user,
                        raffle_id: item.item_id,
                        ticket_random: randomValue,
                        ticket_hash: hash
                    }
                    db.insert('tickets', ticket);
                }

                db.query(`DELETE FROM cart_items WHERE cart_id = '${cart_id}'`);
                io.sockets.in('users').emit('purchase-update', updated_items);
                socket.emit('cart-purchased');
            })
            
        }
    })
}

async function onItemExpire(id) {
    await db.query(`DELETE FROM cart_items WHERE cart_id = '${id}'`);
    let items = await db.query(`SELECT GROUP_CONCAT(ci.ticket_num) as expired_nums, ci.item_id, c.user FROM cart_items ci JOIN carts c ON (c.id = ci.cart_id) WHERE item_id IN (SELECT DISTINCT item_id FROM cart_items WHERE cart_id = '${id}') GROUP BY ci.item_id`)
    items.map(m => { m.expired_nums = m.expired_nums.split(','); return m; });
    io.sockets.in('users').emit('reservation-update', items);
    if(connected.users[item.user]) io.sockets.connected[connected.users[item[0].user]].emit('cart-update');
}

module.exports.process = Process;